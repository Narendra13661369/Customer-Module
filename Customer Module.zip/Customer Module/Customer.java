package com.example.demo.entities;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Customer {
	@Id
	@Size(min = 3, max = 25, message = "UserId should be min of 3 chars & max of 25 chars.")
	@Pattern(regexp = "[0-9]+", message = "UserId should be Numeric, No space allowed.")
	private String customerId;
	
	@NotBlank(message = "Name can't be Blank.")
	private String customerName;
	
	@Pattern(regexp = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$", message = "EmailId Should be Contain: ^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$ These Chars.")
	@NotBlank(message = "Name can't be Blank.")
	@Email(message = "Please enter valid Email eg: yourname@ipru.com.")
	private String emailId;
	
	@Pattern(regexp = "[a-zA-Z0-9]{8,}", message = "At least 8 characters,only uppercase lowercase and digits allowed.")
	@NotBlank(message = "Password can't be Blank.")
	private String customerPassword;

	@Pattern(regexp = "(0|91)?[7-9][0-9]{9}", message = "Mobile Number should be in Numaric Values only and It Doesn't Allow above/below than 10 Chars.")
	@NotBlank(message = "Mobile Number can't be Blank.")
	private String mobileNumber;
	
	private Address address;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String customerId, String customerName, String customerPassword, String mobileNumber, String emailId, Address address) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPassword = customerPassword;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
		this.address = address;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}


}