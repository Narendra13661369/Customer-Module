package com.example.demo.exception;

public class AddressException extends Exception {
	public AddressException(String message) {
		super(message);
	}
}
