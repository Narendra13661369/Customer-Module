package com.example.demo.service;

import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Address;
import com.example.demo.entities.Customer;
import com.example.demo.entities.LoginDTO;
import com.example.demo.exception.CustomerException;
import com.example.demo.exception.LoginException;
import com.example.demo.repository.IAddressRepository;
import com.example.demo.repository.ICustomerRepository;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	private ICustomerRepository customerRepo;
	@Autowired
	private IAddressRepository addressRespo;

	@Override
	public Customer addCustomer(Customer customer) throws CustomerException {

		Customer foundCustomer = this.customerRepo.findByEmailId(customer.getEmailId());
		if (foundCustomer != null)
			throw new CustomerException("Customer exists with given Email, please try with alternate email.");
		

		Address address=this.addressRespo.save(customer.getAddress());
		customer.setAddress(address);
		return this.customerRepo.save(customer);

	}

	@Override
	public Customer updateCustomer(Customer customer) throws CustomerException {

		return this.customerRepo.save(customer);
	}

	@Override
	public String cancelCustomer(String emailId) throws CustomerException {
		Customer foundCustomer = this.customerRepo.findByEmailId(emailId);
		if (foundCustomer == null)
			throw new CustomerException("Customer does't  exists with given Email to delete.");

		this.customerRepo.delete(foundCustomer);
		return "Customer account deleted successfully";

	}

	@Override
	public List<Customer> showAllCustomers() {
		return customerRepo.findAll();
	}

	@Override
	public Customer showCustomerByEmailId(String emailId) throws CustomerException {
		Customer foundCustomer = this.customerRepo.findByEmailId(emailId);
		if (foundCustomer == null)
			throw new CustomerException("Customer Id doesn't exist");
		return foundCustomer;

	}

	@Override
	public String login(LoginDTO customer) throws LoginException {
		Customer foundCustomer = this.customerRepo.findByEmailId(customer.getEmailId());

		if (foundCustomer == null)

			throw new LoginException("User Email Does Not Exists.");

		if (!foundCustomer.getCustomerPassword().equals(customer.getCustomerPassword()))

			throw new LoginException("Password Doesn't Match.");

		String issuer = customer.getEmailId();
		Date expiry = new Date(System.currentTimeMillis() + (60 * 60 * 1000));

		String jwt = Jwts.builder().setIssuer(issuer).setExpiration(expiry)
				.signWith(SignatureAlgorithm.HS512, "Secret123").compact();

		return jwt;
	}
}