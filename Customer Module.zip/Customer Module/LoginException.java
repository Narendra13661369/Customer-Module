package com.example.demo.exception;

public class LoginException extends Exception{
	public LoginException(String message) {
		super(message);
	}
}
