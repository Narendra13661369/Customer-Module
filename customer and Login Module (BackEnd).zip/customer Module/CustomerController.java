package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Customer;
import com.example.demo.entities.LoginDTO;
import com.example.demo.exception.CustomerException;
import com.example.demo.exception.LoginException;
import com.example.demo.service.ICustomerService;

@CrossOrigin(value="http://localhost:3000/")
@RestController
@RequestMapping("api")
public class CustomerController {
	@Autowired
	private ICustomerService custService;

	@GetMapping("customers")
	public List<Customer> getAllCustomers() {
		return this.custService.showAllCustomers();
	}

	@PostMapping("customer")
	public Customer createCustomer(@Valid@RequestBody Customer user) throws CustomerException {
		return this.custService.addCustomer(user);
	}

	@DeleteMapping("customer/{emailId}")
	public String cancelCustomer(@PathVariable("emailId") String emailId) throws CustomerException {
		return this.custService.cancelCustomer(emailId);
	}

	@PutMapping("customer")
	public Customer updateCustomer(@Valid@RequestBody Customer person) throws CustomerException {
		return this.custService.updateCustomer(person);
	}

	@GetMapping("customer/{emailId}")
	public Customer showCustomerByEmailId(@PathVariable("emailId") String emailId)throws CustomerException {
		return this.custService.showCustomerByEmailId(emailId);	
	}

	@PostMapping("login")
	public String loginDTO(@Valid@RequestBody LoginDTO customer, HttpServletResponse response) throws LoginException {

		Cookie cookie = new Cookie("jwt", this.custService.login(customer));

		response.addCookie(cookie);
		return "Login Success !";
	}

	@PostMapping("logout")
	public String logout(HttpServletResponse response) {
		Cookie cookie = new Cookie("jwt", "");
		response.addCookie(cookie);
		return "Logout Success.";
	}
}