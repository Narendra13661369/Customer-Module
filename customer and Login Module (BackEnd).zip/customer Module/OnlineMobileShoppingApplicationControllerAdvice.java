package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.demo.exception.CustomerException;
import com.example.demo.exception.LoginException;

@RestControllerAdvice
public class OnlineMobileShoppingApplicationControllerAdvice {
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(CustomerException.class)
	public String customerExceptionHandler(Exception e) {
		return e.getMessage();
	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(LoginException.class)
	public String loginExceptionHandler(Exception e) {
		return e.getMessage();
	}
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException e) {

		Map<String, String> errorMap = new HashMap<>();

		e.getBindingResult().getAllErrors().forEach (erorObject -> {
			String fieldName = ((FieldError) erorObject).getField();
			String errorMsg = erorObject.getDefaultMessage();
			errorMap.put(fieldName, errorMsg);

		});

		return errorMap;

	}
}
