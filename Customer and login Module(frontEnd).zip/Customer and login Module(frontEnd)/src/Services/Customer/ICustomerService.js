import http from '../Customer/http-common';

class ICustomerService{
    getAllCustomers(){
        return http.get("customers");
    }
    showCustomerByEmailId(emailId){
        return http.get("customer/"+emailId);
    }
    loginDTO(DTO){
        return http.post("login",DTO);
    }
    cancleCustomer(emailId){
        return http.delete("customer/"+emailId);
    }
    logout(){
        return http.post("logout");
    }
    createCustomer(customer){
        return http.post("customer",customer);
    }
    updateCustomer(customer){
        return http.put("customer",customer);
    }
}

export default new ICustomerService();