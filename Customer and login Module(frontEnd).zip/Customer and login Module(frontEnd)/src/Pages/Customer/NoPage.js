const NoPage = () => {

    return (<h3>Page not Found.</h3>);

}
export default NoPage;