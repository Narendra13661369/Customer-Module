import { Outlet, Link } from "react-router-dom";

const LayoutCustomer = () => {
    return (
        <>
            <nav className="navbar navbar-expand-sm bg-light justify-content-center">
                <ul className="navbar-nav">
                    <li className="nav-item">
                        <Link className="nav-link" to="Home">Home</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="login">Login</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="addAccount">Create New Account</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="updateAccount">Update Account</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="changePassword">Change Password </Link>
                    </li>

                    <li className="nav-item">
                        <Link className="nav-link" to="displayAllcustomers">Display All Accounts</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="customerByEmailId">Display Acccount</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="deleteAccount">Delete Account</Link>
                    </li>

                    <li className="nav-item">
                        <Link className="nav-link" to="logout">Logout</Link>
                    </li>


                </ul>
            </nav>
            <Outlet />
       
           
        </>
         
    );
}

export default LayoutCustomer;