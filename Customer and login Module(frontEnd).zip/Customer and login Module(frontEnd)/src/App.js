import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LayoutCustomer from './Pages/Customer/Layout';
import NoPage from './Pages/Customer/NoPage';
import DisplayAllCustomers from './Components/Customer/DisplayAllCustomers';
import LoginDTO from './Components/Customer/LoginDTO';
import DeleteCustomer from './Components/Customer/DeleteCustomer';

import Logout from './Components/Customer/Logout';
import AddCustomer from './Components/Customer/AddCustomer';
import UpdateCustomer from './Components/Customer/UpdateCustomer';
import Home from './Components/Customer/Home';
import ForgotCustomer from './Components/Customer/Forgot';
import AllCustomers from './Components/Customer/Allcustomers';

function App() {
  return (
    <>
      <p className="pt-9">ONLINE MOBILE SHOPPING APPLICATION</p>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LayoutCustomer />}>
            <Route path="home" element={<Home />} />
            <Route path="addAccount" element={<AddCustomer />} />

            <Route path="updateAccount" element={<UpdateCustomer />} />
            <Route path="changePassword" element={<ForgotCustomer />} />

            <Route path="customerByEmailId" element={<AllCustomers />} />
            <Route path="displayAllcustomers" element={<DisplayAllCustomers />} />
            <Route path="deleteAccount" element={<DeleteCustomer />} />
            <Route path="logout" element={<Logout />} />
            <Route path="login" element={<LoginDTO />} />
            <Route path="*" element={<NoPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}
export default App;
