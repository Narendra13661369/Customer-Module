import React from "react";
import { NavLink } from "react-router-dom";
import './My.css';

const Home = () => {
    return (
        <>
           
                <div className="bImg3">
                    <div className="home-page">
                        <div className="home-div">
                            <div className="../../App">
                                <li>
                                    <NavLink to="/login">Login</NavLink>
                                </li>
                                <li>
                                    <NavLink to="/logout">Logout</NavLink>
                                </li>
                                <li>
                                    <NavLink to="/addAccount">Create New Account</NavLink>
                                </li>


                                <p className="pt-5">WELCOME TO</p>
                                <h2>ONLINE MOBILE SHOPPING APPLICATION</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </>
      
    )
}
export default Home;