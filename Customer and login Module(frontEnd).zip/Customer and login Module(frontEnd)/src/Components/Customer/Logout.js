import { useState } from "react";
import ICustomerService from "../../Services/Customer/ICustomerService";
import './My.css' ;

const Logout = () => {

    const [logout] = useState(
    );

    // const [isEdit, setIsEdit] = useState(false);
    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    const customerLogout = (e) => {
        e.preventDefault();
        console.log(logout);
        ICustomerService.logout()
            .then((response) => {
                console.log(response.data)
                setMsg("Logout Sucessfull !");
                setErrorMsg(undefined);
            })
            .catch((error) => {
                console.log(error)
                setErrorMsg("Logout Failed");
                setMsg(undefined);
            })
    }
    return (
        <><div className="bgImg">
            <div className="Logout">
            <p className="pt-5">Logout</p>
                {msg && <h5 className="alert alert-success">{msg}</h5>}
                {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
                
                <input onClick={customerLogout} type="Button" value="logout" />
            </div>
            </div>
        </>
    );
};

export default Logout;