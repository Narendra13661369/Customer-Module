import { useState } from "react";
import ICustomerService from "../../Services/Customer/ICustomerService";
import { NavLink } from "react-router-dom";
import './My.css';

const LoginDTO = () => {

    const [DTO, setDTO] = useState(
        {
            "emailId": "",
            "customerPassword": ""
        }
    );

    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setDTO((preDTO) => ({ ...preDTO, [name]: value }))
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(DTO);
        ICustomerService.loginDTO(DTO)
            .then((response) => {
                console.log(response.data)
                setMsg("Login Sucessfull !");
                setErrorMsg(undefined);
            })
            .catch((error) => {
                console.log(error)
                setErrorMsg("Login Failed, Please Enter Correct Email/Password !");
                setMsg(undefined);
            })
    }
    return (
        <>
            <div className="bgImg">
                <li>
                    <NavLink to="/Home">Home</NavLink>
                </li>
                <li>
                    <NavLink to="/logout">Logout</NavLink>
                </li>
                <div className="LoginDTO">

                <p className="pt-5">Login</p>
                    {msg && <h5 className="alert alert-success">{msg}</h5>}
                    {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
                    <form onSubmit={handleSubmit}>
                        Customer EmailID:
                        <input type="email" name="emailId" value={DTO.emailId} onChange={handleChange} /><br /><br />
                        Password:
                        <input type="password" name="customerPassword" value={DTO.customerPassword} onChange={handleChange} /><br /><br />
                        <input onClick={handleSubmit} type="Button" value="login" />

                        <li>
                            <NavLink to="/addAccount">Create New Account</NavLink>
                        </li>
                        <li>
                            <NavLink to="/changePassword">Forgot Password/MobileNumber/UserName</NavLink>
                        </li>
                        <li>
                            <NavLink to="/logout">Logout</NavLink>
                        </li>
                    </form>
                </div>
            </div>
        </>
    );
};

export default LoginDTO;