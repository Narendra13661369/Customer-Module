import { useState } from "react";
import ICustomerService from "../../Services/Customer/ICustomerService";
import { NavLink } from "react-router-dom";
import './My.css' ;

function AllCustomers() {

    const [customers, setCustomers] = useState(
        {
            "emailId": "",
            "customerName": "",
            "customerPassword": "",
            "mobileNumber": ""
        }
    );


    const [customerEmailId, setCustomerEmailId] = useState(
        {
            "emailId": ""
        }

    );

    const [isSubmitted, setIsSubmitted] = useState(false);
    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setCustomerEmailId((preCustomerEmailId) => ({ ...preCustomerEmailId, [name]: value }))
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(customerEmailId.emailId);
        ICustomerService.showCustomerByEmailId(customerEmailId.emailId)
            .then((response) => {
                console.log(response.data);
                setCustomers(response.data)
                console.log(customers)
                setMsg("Successfully Displayed")
                setIsSubmitted(true)
            })
            .catch((error) => {
                console.log(error)
                setErrorMsg("Failed to Display")
                setIsSubmitted(false)
            })
    };

    const customerEmail = (
        <><div className="bImg9">
            <li>
                <NavLink to="/Home">Home</NavLink>
            </li>
            <li>
                <NavLink to="/displayAllcustomers">Display All Accounts</NavLink>
            </li>

            <div className="Customer"></div>

            <p className="pt-5">All Customers</p>
            {msg && <h5 className="alert alert-success">{msg}</h5>}
            {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}

            <form onSubmit={handleSubmit}>
                Customer EmailId:
                <input type="email" name="emailId" value={customerEmailId.emailId} onChange={handleChange}></input><br /><br />
                <input onClick={handleSubmit} type="Button" value="Search" />
            </form>
            </div>
        </>
    );

    const customersTable = (
        <><div className="bImg9">
            <li>
                <NavLink to="/Home">Home</NavLink>
            </li>
            <h3>Display Account By EmailID:</h3>
            {msg && <h5 className="alert alert-success">{msg}</h5>}

            <table className="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Customer Name</th>
                        <th>Customer EmailId</th>
                    </tr>
                </thead>
                <tbody>
                    {/* {
                        customers.map((customer) => (
                            <tr key={customer.emailId}>
                                <td>{customer.customerName}</td>
                                <td>{customer.mobileNumber}</td>
                                <td>{customer.emailId}</td>
                                <td>{customer.customerPassword}</td>
                            </tr>
                        )
                        ) 
                    } */}

                    <td>
                        {customers.customerName}

                    </td>
                    <td>
                        {customers.emailId}
                    </td>

                </tbody>
            </table>
            </div>
        </>

    );
    return (
        isSubmitted ? customersTable : customerEmail
    );
}
export default AllCustomers;