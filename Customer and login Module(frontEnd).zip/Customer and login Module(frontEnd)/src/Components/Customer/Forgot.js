import ICustomerService from "../../Services/Customer/ICustomerService";
import { useState } from "react";
import { NavLink } from "react-router-dom";
import './My.css' ;

const ForgotCustomer = () => {

    const [customer, setCustomer] = useState(
        {
            "emailId": "",
            "customerName": "",
            "customerPassword": "",
            "mobileNumber": ""
        }
    );

    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setCustomer((preCustomer) => ({ ...preCustomer, [name]: value }))
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(customer);
        ICustomerService.updateCustomer(customer)
            .then((response) => {
                console.log(response.data)
                setMsg("Customer Details Updated Sucessfully !");
                setErrorMsg(undefined);
            })
            .catch((error) => {
                console.log(error)
                setErrorMsg("Failed to Update Customer Details !");
                setMsg(undefined);
            })
    }
    return (
        <><div className="bImg">
            <div className="Customer">
                <li>
                    <NavLink to="/Home">Home</NavLink>
                </li>
                <p className="pt-5">Forgotten Password/UserName/MobileNumber/EmailID</p>
                {msg && <h5 className="alert alert-success">{msg}</h5>}
                {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
                <form onSubmit={handleSubmit}>
                    <br />
                    Full Name:
                    <input type="text" name="customerName" value={customer.customerName} onChange={handleChange} /><br /><br />
                    EmailId:
                    <input type="email" name="emailId" value={customer.emailId} onChange={handleChange} /><br /><br />
                    Create New Password:
                    <input type="password" name="customerPassword" value={customer.customerPassword} onChange={handleChange} /><br /><br />
                    Mobile Number:
                    <input type="number" name="mobileNumber" value={customer.mobileNumber} onChange={handleChange} /><br /><br />
                    <input onClick={handleSubmit} type="Button" value="Update Account" />
                </form>

            </div>
            </div>
        </>
    );

};
export default ForgotCustomer;