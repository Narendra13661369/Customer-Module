import { useEffect, useState } from "react";
import ICustomerService from "../../Services/Customer/ICustomerService";
import { NavLink } from "react-router-dom";
import './My.css';

function DisplayAllCustomers() {

    const [customers, setCustomers] = useState([
        {
            "emailId": "",
            "customerName": "",
            "customerPassword": "",
            "mobileNumber": ""
        }
    ]);

    useEffect(() => {
        loadAllCustomers();
    }, []);

    const loadAllCustomers = () => {
        ICustomerService.getAllCustomers()
            .then((response) => {
                console.log(response.data);

                setCustomers(response.data);
            })
            .catch((error) => { console.log(error) })
    };

    // const [isEdit, setIsEdit] = useState(false);
    const [msg] = useState(undefined);
    const [errorMsg] = useState(undefined);

    const customersTableElement = (
        <><div className="bImg11">
            <li>
                <NavLink to="/Home">Home</NavLink>
            </li>
            <li>
                <NavLink to="/customerByEmailId">Display Account By EmailID</NavLink>
            </li>

            <p className="pt-5">Display All Customers</p>

            {msg && <h5 className="alert alert-success">{msg}</h5>}
            {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
            <table className="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Full Name</th>
                        <th>EmailId</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        customers.map((customer) => (
                            <tr key={customer.emailId}>
                                <td>{customer.customerName}</td>
                                <td>{customer.emailId}</td>
                            </tr>
                        )
                        )
                    }
                </tbody>
            </table><br />
        </div>
        </>

    );
    return (
        <>
            {customersTableElement}
        </>
    );
}
export default DisplayAllCustomers;