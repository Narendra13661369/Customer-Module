import { useState } from "react";
import ICustomerService from "../../Services/Customer/ICustomerService";
import { NavLink } from "react-router-dom";
import './My.css' ;

const DeleteByEmailId = () => {

    const [delet, setDelete] = useState(
        {
            "emailId": ""
        }
    );
    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setDelete((predelete) => ({ ...predelete, [name]: value }))
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(delet.emailId);
        ICustomerService.cancleCustomer(delet.emailId)
            .then((response) => {
                console.log(response.data)
                setMsg("Account DELETED Sucessfully !");
                setErrorMsg(undefined);
            })
            .catch((error) => {
                console.log(error)
                setErrorMsg("Failed to DELETE Account !");
                setMsg(undefined);
            })
    }
    return (
        <><div className="bImg3">
            <div className="Account">
                <li>
                    <NavLink to="/Home">Home</NavLink>
                </li>
                <p className="pt-5">Delete Acccount By EmailID</p>
                {msg && <h5 className="alert alert-success">{msg}</h5>}
                {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
                <form onSubmit={handleSubmit}>
                    Customer EmailId:
                    <input type="email" name="emailId" value={delet.emailId} onChange={handleChange} /><br /><br />
                    <input onClick={handleSubmit} type="Button" value="Delete" />
                </form>
            </div>
            </div>
        </>
    );
};
export default DeleteByEmailId;